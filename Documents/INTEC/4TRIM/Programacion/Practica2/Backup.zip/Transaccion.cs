using System;

namespace Practica2
{
    public abstract class Transaccion
    {
        public enum TransactionType
        {
            Fijo = 0,
            Extra = 1
        }    
        
        public string ID { get; set; }
        private double monto;
        public double Monto
        {
            get { return monto;}
            set { monto = value;}
        }

        private string descripcion;
        public string Descripcion
        {
            get { return descripcion;}
            set { descripcion = value;}
        }

        private string nombre;
        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        private TransactionType tipoTransaccion;
        public TransactionType TipoTransaccion
        {
            get { return tipoTransaccion;}
            set { tipoTransaccion = value;}
        }
        
        private string fechaRegistro;
        public string FechaRegistro
        {
            get { return fechaRegistro;}
            set { fechaRegistro = value;}
        }

        
    }
}
