using System.Collections.Generic;

/** 
 * Class for a Vending Machine.  Contains a hashtable mapping item names to item data, as 
 * well as the current balance of money that has been deposited into the machine.
 */

public class Vending {
  private double balance;
  private static Dictionary<string, VendingItem> Stock = new Dictionary<string, VendingItem>();
    
  public Vending(int numCandy, int numGum) {
    Stock.Add("Candy", new VendingItem(1.25, numCandy));
    Stock.Add("Gum", new VendingItem(.5, numGum));
    this.balance = 0;
  }
  
  /** resets the Balance to 0 */
  public void resetBalance () {
    this.balance = 0;
  }
  
  /** returns the current balance */
  public double getBalance () {
    return this.balance;
  }
  
  /** adds money to the machine's balance
    * @param amt how much money to add
    * */
  public void addMoney (double amt) {
    this.balance = this.balance + amt;
  }
    
  /** attempt to purchase named item.  Message returned if
    * the balance isn't sufficient to cover the item cost.
    * 
    * @param name The name of the item to purchase ("Candy" or "Gum")
    */
  public void select (string name) {
    if (Stock.ContainsKey(name)) {
      VendingItem item = Stock[name];
      if (balance >= item.price) {
        item.purchase(1);
        this.balance = this.balance - item.price;
      }
      else
        System.Console.WriteLine("Gimme more money");
    }
    else System.Console.WriteLine("Sorry, don't know that item");
  }
      
}