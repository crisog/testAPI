using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using System.Linq;
using static Practica2.Transaccion;
using System.Globalization;

namespace Practica2
{
    public class Usuario
    {

        public Usuario()
        {
            ingresos = new List<Ingreso>();
            gastos = new List<Gasto>();
        }
        public int Id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        private static List<Ingreso> ingresos;
        public List<Ingreso> Ingresos
        {
            get { return ingresos; }
        }

        private static List<Gasto> gastos;
        public List<Gasto> Gastos
        {
            get { return gastos; }
        }

        public void AgregarIngreso(int userId, double monto, string nombre, string descripcion, string fechaEstimada, TransactionType transType)
        {
            using (var context = new ApplicationDbContext())
            {//DateTime.ParseExact(DateTime.Now.ToShortDateString(), "dd/MM/yyyy", CultureInfo.InvariantCulture).ToShortDateString()
                Ingreso ingreso = new Ingreso
                {
                    FechaRegistro = DateTime.Now.ToShortDateString(),
                    FechaEstimada = fechaEstimada,
                    Nombre = nombre,
                    Monto = monto,
                    UsuarioId = userId,
                    Descripcion = descripcion,
                    TipoTransaccion = transType
                };
                ingresos.Add(ingreso);
                context.Ingresos.Add(ingreso);
                context.SaveChanges();
            }

        }
        public void AgregarGasto(int userId, double monto, string nombre, string descripcion, TransactionType transType, string ingresoAsociado) 
        {
            using (var context = new ApplicationDbContext())
            {
                Gasto gasto = new Gasto
                {
                    FechaRegistro = DateTime.Now.ToShortDateString(),
                    Monto = monto,
                    Nombre = nombre,
                    Descripcion = descripcion,
                    UsuarioId = userId,
                    TipoTransaccion = transType,
                    IngresoAsociadoId = ingresoAsociado
                };
                gastos.Add(gasto);
                context.Gastos.Add(gasto);
                context.SaveChanges();
            }
        }

        public static Usuario CrearUsuario(string username, string password)
        {

            using (var context = new ApplicationDbContext())
            {
                var usuario = new Usuario
                {
                    Username = username,
                    Password = HashPassword(password)
                };
                context.Usuarios.Add(usuario);
                context.SaveChanges();
                Console.WriteLine("\n Usuario Creado Satisfactoriamente.");
                return usuario;
            }
        }

        public static bool UsuarioExiste(string username)
        {
            using (var context = new ApplicationDbContext())
            {
                var usuario = context.Usuarios.Where(x => x.Username == username).ToList();
                if ((usuario != null) && (!usuario.Any()))
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }

        public static void VisualizarGastos(Usuario user) {

            using (var context = new ApplicationDbContext())
            {
                gastos = context.Gastos.Where(x => x.UsuarioId == user.Id).ToList();
               
                int k = 1;
                foreach (var gasto in gastos)
                {
                    System.Console.WriteLine($"{k}. {gasto.Nombre}");
                    k++;
                }
            }
        }

        public static void VisualizarIngresos(Usuario user) {

            using (var context = new ApplicationDbContext())
            {
                ingresos = context.Ingresos.Where(x => x.UsuarioId == user.Id).ToList();
                
                int k = 1;
                foreach (var ingreso in ingresos)
                {
                    System.Console.WriteLine($"{k}. {ingreso.Nombre}");
                    k++;
                }
            }
        }
        
        public static void VisualizarIngresosPorMes(Usuario user, int month) {

            using (var context = new ApplicationDbContext())
            {
                ingresos = context.Ingresos.Where(x => x.UsuarioId == user.Id && DateTime.ParseExact(x.FechaEstimada, "dd/MM/yyyy", null).Month == month || x.UsuarioId == user.Id && x.TipoTransaccion == TransactionType.Fijo).ToList();
                int k = 1;
                Console.WriteLine("\n Tus ingresos del mes son: ");
                foreach (var ingreso in ingresos)
                {
                    System.Console.WriteLine($"{k}. {ingreso.Nombre} RD${ingreso.Monto}");
                    k++;
                }
            }
        }

        public static void VisualizarGastosPorMes(Usuario user, int month) {

            using (var context = new ApplicationDbContext())
            {
                gastos = context.Gastos.Where(x => x.UsuarioId == user.Id && DateTime.ParseExact(x.FechaRegistro, "M/dd/yyyy", null).Month == month || x.UsuarioId == user.Id && x.TipoTransaccion == TransactionType.Fijo).ToList();
                int k = 1;
                Console.WriteLine("\n Tus gastos del mes son: ");
                foreach (var gasto in gastos)
                {
                    System.Console.WriteLine($"{k}. {gasto.Nombre} RD${gasto.Monto}");
                    k++;
                }
            }
        }

        public static bool ValidarCredenciales(string username, string password)
        {
            using (var context = new ApplicationDbContext())
            {
                var usuario = context.Usuarios.Where(x => x.Username == username).ToList();
                if ((usuario != null) && (!usuario.Any()))
                {
                    return false;
                }
                else
                {
                    if (usuario[0].Password == HashPassword(password))
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        static string HashPassword(string rawData)
        {
            // Create a SHA256   
            using (SHA256 sha256Hash = SHA256.Create())
            {
                // ComputeHash - returns byte array  
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));

                // Convert byte array to a string   
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

    }
}
