﻿using System;
using NUnit.Framework;

namespace Lab5
{
    public class Program
    {
        static void Main(string[] args)
        {
            Vending vendingMachine = new Vending(10, 10);
            vendingMachine.addMoney(100);
            vendingMachine.select("Gum");
            var balance = vendingMachine.getBalance();
            Console.WriteLine("Compraste un Gum.");
            System.Console.WriteLine($"Balance actual: {balance}");  
        }
    }

    [TestFixture]
    class ProgramTests
    {
        [TestCase(200, "Candy", 198.75)]
        [TestCase(100, "Gum", 99.5)]
        public void Should_Return_Correct_Balance(double money, string vendingItem, double z)
        {
            Vending vendingMachineTest = new Vending(10, 10);
            vendingMachineTest.addMoney(money);
            vendingMachineTest.select(vendingItem);
            var balance = vendingMachineTest.getBalance();
            Assert.AreEqual(z, balance);
        }
    }
}
