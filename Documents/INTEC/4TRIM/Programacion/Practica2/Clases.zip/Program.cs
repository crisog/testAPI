﻿using System;
using System.Linq;
using static Practica2.Usuario;

namespace Practica2
{
    public class Program
    {
        static void Main(string[] args) 
        {
            Login();
        }

        public static void Login() {
            string pass;
            string username;
            int option;
            Console.WriteLine("Bienvenido al sistema de finanzas personales.");
            Console.WriteLine("1. Iniciar Sesión. ");
            Console.WriteLine("2. Crear una cuenta. ");
            Console.Write("\n Qué opción desea elegir?: ");
            option = int.Parse(Console.ReadLine());
            switch (option)
            {
                case 1:
                    Console.Write("\n Usuario: ");
                    username = Console.ReadLine();
                    System.Console.Write("\n Contraseña: ");
                    pass = null;
                    do
                    {
                        ConsoleKeyInfo key = Console.ReadKey(true);
                        if (key.Key != ConsoleKey.Backspace && key.Key != ConsoleKey.Enter)
                        {
                            pass += key.KeyChar;
                            Console.Write("*");
                        }
                        else
                        {
                            if (key.Key == ConsoleKey.Backspace && pass.Length > 0)
                            {
                                pass = pass.Substring(0, (pass.Length - 1));
                                Console.Write("\b \b");
                            }
                            else if (key.Key == ConsoleKey.Enter)
                            {
                                break;
                            }
                        }
                    } while (true);
                    if (ValidarCredenciales(username, pass) == true)
                    {
                        Console.WriteLine();
                        Console.WriteLine("\n Se ha logeado satisfactoriamente.");
                        Console.WriteLine("\n Presione <Enter> para ir al menú principal.");
                        Usuario usuario;
                        using (var context = new ApplicationDbContext())
                        {
                             usuario = context.Usuarios.Where(x => x.Username == username).FirstOrDefault();
                        }
                        Menu(usuario);
                    }
                    else
                    {
                        Console.WriteLine("Las credenciales son incorrectas.");
                        Console.WriteLine("Presione <Enter> para volver al inicio.");
                        Console.ReadKey();

                    }
                    break;

                case 2:
                    Console.Write("Introduzca el nombre de usuario que desea registrar: ");
                    username = Console.ReadLine();
                    if (UsuarioExiste(username) == true)
                    {
                        Console.WriteLine("Ya existe un usuario con este nombre.");
                    }
                    else
                    {
                        Console.Write("Contraseña: ");
                        pass = null;
                        do
                        {
                            ConsoleKeyInfo key = Console.ReadKey(true);
                            if (key.Key != ConsoleKey.Backspace && key.Key != ConsoleKey.Enter)
                            {
                                pass += key.KeyChar;
                                Console.Write("*");
                            }
                            else
                            {
                                if (key.Key == ConsoleKey.Backspace && pass.Length > 0)
                                {
                                    pass = pass.Substring(0, (pass.Length - 1));
                                    Console.Write("\b \b");
                                }
                                else if (key.Key == ConsoleKey.Enter)
                                {
                                    break;
                                }
                            }
                        } while (true);
                        Console.WriteLine();
                        var user = CrearUsuario(username, pass);
                        Menu(user);
                    }
                    break;
            }
        }

        public static void Menu(Usuario user)
        {
            string nombre;
            double monto;
            string descripcion;
            string fechaEstimada;
            string type;
            int eleccion;
            dynamic month;

            Menu:
            System.Console.WriteLine("1. Registrar un ingreso.");
            System.Console.WriteLine("2. Registrar un gasto.");
            System.Console.WriteLine("3. Visualizar ingresos mensuales.");
            System.Console.WriteLine("4. Visualizar gastos mensuales.");
            System.Console.Write("\n Qué opción desea elegir? (1-4): ");
            eleccion = int.Parse(Console.ReadLine());
            switch (eleccion)
            {
                
                case 1:
                    System.Console.Write("Introduzca el nombre del ingreso: ");
                    nombre = Console.ReadLine();
                    Console.Write("Introduzca la descripción del ingreso: ");
                    descripcion = Console.ReadLine();
                    Console.Write("Introduzca el monto del ingreso: ");
                    monto = double.Parse(Console.ReadLine());
                    Console.Write("Introduzca la fecha estimada del ingreso: ");
                    fechaEstimada = Console.ReadLine();
                typeIng:
                    Console.Write("\n Es un ingreso fijo o extra?: ");
                    type = Console.ReadLine();
                    if (type.ToLower() == "fijo")
                        user.AgregarIngreso(user.Id, monto, nombre, descripcion, fechaEstimada, Transaccion.TransactionType.Fijo);
                    else if (type.ToLower() == "extra")
                        user.AgregarIngreso(user.Id, monto, nombre, descripcion, fechaEstimada, Transaccion.TransactionType.Extra);
                    else
                    {
                        Console.WriteLine("Tipo de ingreso inválido.");
                        goto typeIng;
                    }
                    goto Menu;
                case 2:
                    System.Console.Write("\n Introduzca el nombre del gasto: ");
                    nombre = Console.ReadLine();
                    System.Console.Write("\n Introduzca el monto del gasto: ");
                    monto = double.Parse(Console.ReadLine());
                    System.Console.Write("\n Introduzca la descripción del gasto: ");
                    descripcion = Console.ReadLine();
                    System.Console.Write("\n A que ingreso desea asociar este gasto?: ");
                    VisualizarIngresos(user);
                    int ingresoIndex = int.Parse(Console.ReadLine());
                typeGas:
                    System.Console.Write("\n Es un gasto fijo o extra?: ");
                    type = Console.ReadLine();
                    if (type.ToLower() == "fijo")
                        user.AgregarGasto(user.Id, monto, nombre, descripcion, Transaccion.TransactionType.Fijo, user.Ingresos[ingresoIndex - 1].ID);
                    else if (type.ToLower() == "extra")
                        user.AgregarGasto(user.Id, monto, nombre, descripcion, Transaccion.TransactionType.Extra, user.Ingresos[ingresoIndex - 1].ID);
                    else
                    {
                        System.Console.WriteLine("\n Tipo de gasto inválido.");
                        goto typeGas;
                    }
                    goto Menu;
                case 3:
                    System.Console.Write("\n De qué més desea visualizar sus ingresos? (1-12): ");
                    month = Console.ReadLine();
                    #region
                    switch(month.ToLower()) {
                        case "enero":
                        case "1":
                        VisualizarIngresosPorMes(user, 1);
                        break;

                        case "febrero":
                        case "2":
                        VisualizarIngresosPorMes(user, 2);
                        break;

                        case "marzo":
                        case "3":
                        VisualizarIngresosPorMes(user, 3);
                        break;

                        case "abril":
                        case "4":
                        VisualizarIngresosPorMes(user, 4);
                        break;
                        
                        case "mayo":
                        case "5":
                        VisualizarIngresosPorMes(user, 5);
                        break;

                        case "junio":
                        case "6":
                        VisualizarIngresosPorMes(user, 6);
                        break;

                        case "julio":
                        case "7":
                        VisualizarIngresosPorMes(user, 7);
                        break;

                        case "agosto":
                        case "8":
                        VisualizarIngresosPorMes(user, 8);
                        break;

                        case "septiembre":
                        case "9":
                        VisualizarIngresosPorMes(user, 9);
                        break;

                        case "octubre":
                        case "10":
                        VisualizarIngresosPorMes(user, 10);
                        break;

                        case "noviembre":
                        case "11":
                        VisualizarIngresosPorMes(user, 11);
                        break;

                        case "diciembre":
                        case "12":
                        VisualizarIngresosPorMes(user, 12);
                        break;

                    }
                    #endregion
                    break;
                case 4:
                System.Console.Write("\n De qué més desea visualizar sus gastos? (1-12): ");
                    month = Console.ReadLine();
                    #region
                    switch(month.ToLower()) {
                        case "enero":
                        case "1":
                        VisualizarGastosPorMes(user, 1);
                        break;

                        case "febrero":
                        case "2":
                        VisualizarGastosPorMes(user, 2);
                        break;

                        case "marzo":
                        case "3":
                        VisualizarGastosPorMes(user, 3);
                        break;

                        case "abril":
                        case "4":
                        VisualizarGastosPorMes(user, 4);
                        break;
                        
                        case "mayo":
                        case "5":
                        VisualizarGastosPorMes(user, 5);
                        break;

                        case "junio":
                        case "6":
                        VisualizarGastosPorMes(user, 6);
                        break;

                        case "julio":
                        case "7":
                        VisualizarGastosPorMes(user, 7);
                        break;

                        case "agosto":
                        case "8":
                        VisualizarGastosPorMes(user, 8);
                        break;

                        case "septiembre":
                        case "9":
                        VisualizarGastosPorMes(user, 9);
                        break;

                        case "octubre":
                        case "10":
                        VisualizarGastosPorMes(user, 10);
                        break;

                        case "noviembre":
                        case "11":
                        VisualizarGastosPorMes(user, 11);
                        break;

                        case "diciembre":
                        case "12":
                        VisualizarGastosPorMes(user, 12);
                        break;

                    }
                    #endregion
                    break;
            }
        }
    }
}
