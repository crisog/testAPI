using System.Collections;

public class VendingItem {
  public double price;
  public int numPieces;
  
  public VendingItem(double price, int numPieces) {
    this.price = price;
    this.numPieces = numPieces;
  }
  
  public void restock(int pieces) {
    this.numPieces = this.numPieces + pieces;
  }
  
  public void purchase(int pieces) {
    this.numPieces = this.numPieces - pieces;
  }
}


  